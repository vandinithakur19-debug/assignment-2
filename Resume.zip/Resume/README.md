# Resume

Personal resume page for Vandini Thakur, built with plain HTML and CSS.

## Files
- `index.html` - resume content
- `style.css` - styling (also includes print styles for saving as PDF)

## Preview
Open `index.html` in a browser.
